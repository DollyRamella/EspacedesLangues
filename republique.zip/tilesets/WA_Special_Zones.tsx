<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="WA_Special_Zones" tilewidth="32" tileheight="32" tilecount="12" columns="6">
 <image source="WA_Special_Zones.png" width="192" height="64"/>
</tileset>
