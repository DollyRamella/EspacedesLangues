<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="WA_User_Interface" tilewidth="32" tileheight="32" tilecount="273" columns="13">
 <image source="WA_User_Interface.png" width="416" height="672"/>
</tileset>
