<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="bubbles" tilewidth="32" tileheight="32" tilecount="40" columns="10">
 <image source="Orbz/OrbzPrw.png" width="330" height="132"/>
</tileset>
