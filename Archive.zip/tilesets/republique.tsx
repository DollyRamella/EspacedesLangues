<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="republique" tilewidth="32" tileheight="32" tilecount="10440" columns="120">
 <image source="../republique.png" width="3850" height="2807"/>
</tileset>
