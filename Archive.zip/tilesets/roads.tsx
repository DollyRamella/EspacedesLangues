<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="roads" tilewidth="32" tileheight="32" tilecount="80" columns="8">
 <image source="roads.png" width="256" height="320"/>
 <tile id="68">
  <properties>
   <property name="collides" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
