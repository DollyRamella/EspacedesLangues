<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="plan" tilewidth="32" tileheight="32" tilecount="1599" columns="38">
 <image source="exterior.png" width="1240" height="1240"/>
</tileset>
