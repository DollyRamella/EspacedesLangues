# WorkAdventure Map Starter Kit - Public Folder

In this directory you can put static files (audio files, images except tileset...) that you want to be available in production.
